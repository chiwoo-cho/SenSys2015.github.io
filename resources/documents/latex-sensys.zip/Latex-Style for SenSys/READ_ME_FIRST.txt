The following are simple (to follow), yet very important instructions for the
typesetting of a (nearly) perfect paper for the Sensys Proceedings.

0. Spacing...

Please use the enclosed template .tex file for your paper.

Do NOT change any settings in the preamble of this file. You may add, if
necessary, other styles, but please make sure that those do not conflict with
the original settings. This also goes with the heading styles and sizes, as
well as any default spacing. You may only add spacing instructions to decrease
excessive spacing, or increase very tight spacing.

Please do take this seriously...

1. Spelling...

Some words may have different spelling depending on the English language you
are using. However, for consistency of the whole proceedings, please use the
spellings of such words (e.g., Acknowledgments) in the sample .tex file.

Please make sure that you've spell checked your paper for any typographical
errors.

2. Capitalization...

Please pay attention to the capitalization of the words in the title and the
section headings.

3. Computer Classification System...

Please carefully read the following web site from ACM to find correct and
sufficient categories and keywords for the respective sections in your paper:

http://www.acm.org/about/class/how-to-use

4. A full-length sample...

For your further reference, Sensys 2012 Publication Chair Karthik Dantu has
kindly provided a copy of their Sensys 2011 paper "Programming Micro-Aerial 
Vehicles with Karma" (Karma.pdf). Thank you again, Karthik!


PAYING UTMOST ATTENTION TO AND FOLLOWING THE ABOVE SIMPLE INSTRUCTIONS WILL
HELP US TO TYPESET A (NEARLY) PERFECT PROCEEDINGS FOR THE FUTURE...

Cheers,

Rasit Eskicioglu
2009 and 2014 Publications Chair

